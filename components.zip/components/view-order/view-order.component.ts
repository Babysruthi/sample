import { AssertNotNull } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.css']
})
export class ViewOrderComponent implements OnInit {

  constructor() { }

  p:object|any
  product:object |any
  
  ngOnInit(): void {
    this.product=localStorage.getItem('p')
    this.p=JSON.parse(this.product)
    
    
  }

}
