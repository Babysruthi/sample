import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-orders',
  templateUrl: './view-orders.component.html',
  styleUrls: ['./view-orders.component.css']
})
export class ViewOrdersComponent implements OnInit {

  products : Product[] = [
    {
     image:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPQhfbyY_2gDGk3Jln0IDem0XjYjCuNQkzow&usqp=CAU',
     name:'Chocolate',
     price:100,
     description:'Chocolate never lets us down and always improves our mood. As long as there is chocolate, there will be happiness.',
     quantity:2,
     OrderedOn:'08 October 2008',
     date:'15 October 2008',
     

    },
    {
     image:'https://static-cse.canva.com/image/73337/6.071631bc.png',
     name:'PhotoFrame', 
     price:300, 
     description:'Its a bundle of joy and memories', 
     quantity:1,
     OrderedOn:'20 January 2018',
     date:'27 January 2018',
    },
    {
      image:'https://m.media-amazon.com/images/I/81+d6eSA0eL._UL1500_.jpg',
      name:'Watch',
      price:1000,
      description:'Time is what you make of it.',
      quantity:1,
      OrderedOn:'12 September 2021',
      date:'',
    }
  ];

  


  constructor(private router:Router) { }

  view(p:any)
  {
    localStorage.setItem("p",JSON.stringify(p))
    console.log(JSON.stringify(p))
      this.router.navigate(['viewOrder'])
  }
  ngOnInit(): void {
  }
 
}
class Product
{
  image?:String;
  name?:String;
  price?:number;
  description?:string;
  quantity?:number;
  OrderedOn?:String;
  date?:String;
}

